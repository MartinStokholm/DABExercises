USE RFM_system_au632826
DROP TABLE Reservation
DROP TABLE Citizen
DROP TABLE Booking
DROP TABLE MaintanceIntervention
DROP TABLE Facility

