The entities with multivalued attributes have been made flat, so for example the description on facility is instead just to fields items and usage rules.
The CVR attribute on user is default to NULL but there is no check on the category to enforce a bussnes person to put in CVR number. 
User was not allowed as name for entity so it is named Citizen in the implementation. 
