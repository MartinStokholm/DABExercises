﻿namespace RFMS_v2_app.Models.Dto
{
    public class CitizenCPRDto
    {
        public long CitizenId { get; set; }
        public long CPR { get; set; }

    }
}
