﻿namespace RFMS_v2_app.Models.Dto
{
    public class FacilityGPSAndNameDto
    {
        public string Name { get; set; } = "";
        public double Latitude { get; set; }
        public double Longitude { get; set; }

    }
}
