USE RFMS_au632826_new
DROP TABLE Reservations
DROP TABLE Citizens
DROP TABLE Bookings
DROP TABLE Facilities
DELETE FROM Facilities
DELETE FROM Reservations
DELETE FROM Citizens
DELETE FROM Bookings
DELETE FROM BookingCitizen
DELETE FROM MaintenanceInterventions

